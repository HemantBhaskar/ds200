#!/usr/bin/env python
# coding: utf-8

# In[75]:


import numpy as np
import matplotlib.pyplot as plt
import sys
import csv

# In[76]:

rows=[]
count_state=[]
state=[]

points = np.loadtxt(sys.argv[1], delimiter=',', skiprows=1, usecols=(8))
		
count_native_line = 0
with open(sys.argv[1], 'r') as data_csv:	
    read_csv_data = csv.reader(data_csv, delimiter=',')    
    for value in read_csv_data:
        if count_native_line == 0:
            count_native_line += 1
        else:
            rows.append(value[0])
            count_native_line += 1
    


count=0
count_line=0
for each in rows:
	if count_line==0:
		state_name=each
		#print(state_name)
		count_line+=1
		count+=1
	else:
		if each ==state_name:
				count+=1
				count_line+=1
				if count_line == count_native_line-1:
					count_state.append(count)
					state.append(state_name)

		else:
			count_state.append(count)
			state.append(state_name)
			state_name=each
			count=1
			count_line+=1

avg_state = []
temp=0
for each in count_state:
	avg=0
	for i in range(each):
		avg+=points[temp]
		temp+=1
	avg /= each
	avg_state.append(avg)





fig, ax = plt.subplots(figsize=(15,10))

plt.bar(state, avg_state, color=(0.8, 0.1, 0.1, 0.6))
plt.xlabel('state', fontsize=10)
plt.ylabel('average modal price (wholesale)', fontsize=10)
plt.title('wholesale average modal price of apples per state of INDIA for year 2019')
plt.xticks( fontsize=6, rotation=50)
plt.grid(color='silver', linestyle='-', linewidth=0.4)
for i, v in enumerate(avg_state):
    plt.text(i -0.35, v + 1, str("{0:.2f}".format(round(v,2))), fontsize=6)
plt.show()